﻿using System.ComponentModel.DataAnnotations;
using static Repositories.DataModels.MasterData;

namespace Repositories.DataModels
{
    public class AccountTransaction
    {
        [Key]
        public Guid TransactionId { get; set; }
        public TransactionType TransactionType { get; set; }
        public double TransactionAmount { get; set; }
        public DateTime CreatedOn { get; set; }
        public Guid AccountId { get; set; }
    }
}
