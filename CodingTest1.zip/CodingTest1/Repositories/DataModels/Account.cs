﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;

namespace Repositories.DataModels
{
    public class Account
    {
        [Key]
        public Guid AccountId { get; set; }    
        public double AccountBalance { get; set; }
        public DateTime CreatedOn   { get; set; }   
        public DateTime dateTime { get; set; }
        public Guid UserId { get; set; }
        //public virtual User User { get; set; }
        public virtual List<AccountTransaction> AccountTransactions { get; set; }
    }
}
