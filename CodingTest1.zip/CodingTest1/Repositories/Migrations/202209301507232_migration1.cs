﻿namespace Repositories.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class migration1 : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Accounts", "AccountBalance", c => c.Double(nullable: false));
            AlterColumn("dbo.AccountTransactions", "TransactionType", c => c.Int(nullable: false));
            AlterColumn("dbo.AccountTransactions", "TransactionAmount", c => c.Double(nullable: false));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.AccountTransactions", "TransactionAmount", c => c.Decimal(nullable: false, precision: 18, scale: 2));
            AlterColumn("dbo.AccountTransactions", "TransactionType", c => c.String());
            AlterColumn("dbo.Accounts", "AccountBalance", c => c.Decimal(nullable: false, precision: 18, scale: 2));
        }
    }
}
