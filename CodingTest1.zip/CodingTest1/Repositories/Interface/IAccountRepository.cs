﻿using Repositories.DataModels;

namespace Repositories.Interface
{
    public interface IAccountRepository
    {
        Task<IEnumerable<Account>> GetAccounts();
        Task<Account> GetAccount(Guid accountId);
        Task<Guid> AddUpdateAccount(Account account);
    }
}
