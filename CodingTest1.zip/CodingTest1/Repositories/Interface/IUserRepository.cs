﻿using Repositories.DataModels;

namespace Repositories.Interface
{
    public interface IUserRepository
    {
        Task<User> GetUserDetails(Guid userId);
        Task<IEnumerable<User>> GetUserList();
        Task<Guid> AddEditUser(User userDetails);       
    }
}
