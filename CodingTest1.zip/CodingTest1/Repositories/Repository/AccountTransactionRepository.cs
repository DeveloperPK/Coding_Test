﻿using Repositories.DataModels;
using Repositories.Interface;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

namespace Repositories.Repository
{
    public class AccountTransactionRepository : IAccountTransactionRepository
    {
        CodeTestDatabaseContext db = new CodeTestDatabaseContext();
        public async Task<Guid> AddTransaction(AccountTransaction accountTransaction)
        {
            var transactionDetails = db.Transactions.Where(x => x.TransactionId == accountTransaction.TransactionId);
            if (await transactionDetails.FirstOrDefaultAsync() != null)
            {
                throw new InvalidOperationException("Transactin already exists, can't overrite.");
            }
             using (DbContextTransaction transaction = db.Database.BeginTransaction())
                {
                    db.Transactions.Add(accountTransaction);
                    var accountDetails = await db.Accounts.Where(x => x.AccountId == accountTransaction.AccountId).FirstOrDefaultAsync(); ;
                    accountDetails.AccountBalance = accountTransaction.TransactionType == MasterData.TransactionType.Credit ? (accountDetails.AccountBalance + accountTransaction.TransactionAmount)
                                                        : (accountDetails.AccountBalance - accountTransaction.TransactionAmount);
                    await db.SaveChangesAsync();
                    transaction.Commit();
                    return accountTransaction.TransactionId;
                }

        }

        public async Task<AccountTransaction> GetTransaction(Guid transactionId)
        {
            return await db.Transactions.Where(x => x.TransactionId == transactionId).FirstOrDefaultAsync();
        }

        public async Task<IEnumerable<AccountTransaction>> GetTransactions()
        {
            return await db.Transactions.ToListAsync();
        }        
    }
}
