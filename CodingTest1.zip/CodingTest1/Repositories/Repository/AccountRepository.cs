﻿using Repositories.DataModels;
using Repositories.Interface;
using System.Data.Entity;

namespace Repositories.Repository
{
    public class AccountRepository : IAccountRepository
    {
        CodeTestDatabaseContext db = new CodeTestDatabaseContext();
        public async Task<Guid> AddUpdateAccount(Account account)
        {
         
                var user = db.Accounts.Where(x => x.AccountId == account.AccountId);
                if (user.FirstOrDefault() != null)
                {
                    return account.UserId;
                }
                else
                {

                    using (DbContextTransaction transaction = db.Database.BeginTransaction())
                    {
                            db.Accounts.Add(account);
                            if (account.AccountBalance < 100)
                            {
                                throw new InvalidOperationException("Minimum balance should be 100");
                            }

                            db.Transactions.Add(new AccountTransaction()
                            {
                                TransactionId = Guid.NewGuid(),
                                AccountId = account.AccountId,
                                TransactionType = MasterData.TransactionType.Credit,
                                CreatedOn = DateTime.UtcNow,
                                TransactionAmount = account.AccountBalance
                            });
                            await db.SaveChangesAsync();
                            transaction.Commit();
                            return account.AccountId;
                    }
                }
            

        }

        public async Task<Account> GetAccount(Guid accountId)
        {
           
                return await db.Accounts.Where(x => x.AccountId == accountId).FirstOrDefaultAsync();
        }

        public async Task<IEnumerable<Account>> GetAccounts()
        {
                return await db.Accounts.ToListAsync(); 
        }
    }
}
