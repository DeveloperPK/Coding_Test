﻿using Repositories.DataModels;
using Repositories.Interface;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repositories.Repository
{
    public class UserRepository : IUserRepository
    {
        private CodeTestDatabaseContext db = new CodeTestDatabaseContext();
        public async Task<Guid> AddEditUser(User userDetails)
        {
          
                    var user = db.Users.Where(x => x.UserId == userDetails.UserId);
                    if (user.FirstOrDefault() != null)
                    {
                        return userDetails.UserId;
                    }
                    else
                    {                        
                        db.Users.Add(userDetails);
                        await db.SaveChangesAsync();
                        return userDetails.UserId;
                    }

                            
        }

        public async Task<User> GetUserDetails(Guid userId)
        {       
            return await db.Users.Where(x => x.UserId == userId).FirstOrDefaultAsync();            
        }

        public async Task<IEnumerable<User>> GetUserList()
        {
                return await db.Users.ToListAsync(); ;         
        }
    }
}
