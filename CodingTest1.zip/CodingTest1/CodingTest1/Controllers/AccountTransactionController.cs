﻿using Microsoft.AspNetCore.Mvc;
using Repositories.DataModels;
using Repositories.Interface;
using static Repositories.DataModels.MasterData;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CodingTest1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountTransactionController : ControllerBase
    {
        private IAccountRepository _accountRepository;
        private IAccountTransactionRepository _accountTransactionRepository;
        public AccountTransactionController(IAccountRepository accountRepository, IAccountTransactionRepository accountTransactionRepository)
        {
            _accountRepository = accountRepository;
            _accountTransactionRepository = accountTransactionRepository; 
        }
        // GET: api/<AccountTransactionController>
        [HttpGet]
        public async Task<IEnumerable<AccountTransaction>> Get()
        {
            return await _accountTransactionRepository.GetTransactions();
        }

        // GET api/<AccountTransactionController>/5
        [HttpGet("{id}")]
        public async Task<AccountTransaction> Get( Guid transactionId)
        {
            return await _accountTransactionRepository.GetTransaction(transactionId);
        }

        // POST api/<AccountTransactionController>
        [HttpPost]
        public async Task<IActionResult> Post([FromBody] AccountTransaction accountTransaction)
        {
            if ((accountTransaction.TransactionAmount > 10000) & (accountTransaction.TransactionType == TransactionType.Credit))
            {
                return BadRequest("Deposit amount should be less thatn 1000");
            }
            var accountDetails = await _accountRepository.GetAccount(accountTransaction.AccountId);
            if (accountDetails != null && accountTransaction.TransactionType == TransactionType.Debit)
            {
                if (accountDetails.AccountBalance - accountTransaction.TransactionAmount < 90)
                {
                    return BadRequest("Please mantain minimum balance of 100");
                }
                var amountThreshhold = (accountDetails.AccountBalance) * (0.9);
                if (accountTransaction.TransactionAmount > amountThreshhold)
                {
                    return BadRequest(" User cannot withdraw more than 90% of their total balance from an\r\n\r\naccount in a single transaction");
                }
            }
            await _accountTransactionRepository.AddTransaction(accountTransaction);
            return Created("~/api/AccountTransaction/"+accountTransaction.TransactionId, accountTransaction);
        }


        // PUT api/<AccountTransactionController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<AccountTransactionController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
