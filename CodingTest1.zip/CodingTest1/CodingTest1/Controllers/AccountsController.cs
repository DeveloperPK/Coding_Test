﻿using Microsoft.AspNetCore.Mvc;
using Repositories.DataModels;
using Repositories.Interface;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace CodingTest1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountsController : ControllerBase
    {
        private IAccountRepository _account;

        public AccountsController(IAccountRepository account)
        {
            _account = account;
        }


        // GET: api/<AccountsController>
        [HttpGet]
        public async Task<IEnumerable<Account>> Get()
        {
            return await _account.GetAccounts();
        }

        // GET api/<AccountsController>/5
        [HttpGet("{id}")]
        public async Task<Account> Get(Guid id)
        {
            return await _account.GetAccount(id);
        }

        // POST api/<AccountsController>
        [HttpPost]
        public async Task<IActionResult> Post([FromBody] Account accountDetails)
        {
            try
            {
                return Ok(await _account.AddUpdateAccount(accountDetails));
            }
            catch (Exception exc)
            {
                return BadRequest(exc.Message);
            }
                
        }

        // PUT api/<AccountsController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<AccountsController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
